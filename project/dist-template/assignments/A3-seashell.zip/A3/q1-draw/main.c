///////////////////////////////////////////////////////////////////////////// 
// INTEGRITY STATEMENT (v3)
//
// By signing your name and ID below you are stating that you have agreed
// to the online academic integrity statement:
// https://student.cs.uwaterloo.ca/~cs136/current/assignments/integrity.shtml
/////////////////////////////////////////////////////////////////////////////
// I received help from and/or collaborated with: 
 
// ERROR_NO_INTEGRITY_STATEMENT 
//  
// Name: ERROR_NO_NAME 
// login ID: ERROR_NO_LOGIN 
///////////////////////////////////////////////////////////////////////////// 


#include "cs136.h"

// IMPORTANT: review draw.txt to see the input format

void draw_box(int width, int height, char c) {
  
}

void draw_xbox(int size) {
  
}

///////////////////////////////////////////////////////
// You do not need to modify the rest of the program //
///////////////////////////////////////////////////////

int main(void) {
  int BOX = lookup_symbol("box");
  int XBOX = lookup_symbol("xbox");
  // if there is any invalid input, the program simply stops
  //   with no error message
  while (1) {
    int cmd = read_symbol();
    if (cmd == BOX) {
      int width = read_int();
      int height = read_int();
      int c = read_char(true);
      if (height == READ_INT_FAIL || c == READ_CHAR_FAIL) {
        break;
      }
      draw_box(width, height, c);
    } else if (cmd == XBOX) {
      int size = read_int();
      if (size == READ_INT_FAIL) {
        break;
      }
      draw_xbox(size);
    } else {
      break;
    }
    printf("\n");
  }
}
