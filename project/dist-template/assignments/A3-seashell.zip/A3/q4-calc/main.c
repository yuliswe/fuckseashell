///////////////////////////////////////////////////////////////////////////// 
// INTEGRITY STATEMENT (v3)
//
// By signing your name and ID below you are stating that you have agreed
// to the online academic integrity statement:
// https://student.cs.uwaterloo.ca/~cs136/current/assignments/integrity.shtml
/////////////////////////////////////////////////////////////////////////////
// I received help from and/or collaborated with: 
 
// ERROR_NO_INTEGRITY_STATEMENT 
//  
// Name: ERROR_NO_NAME 
// login ID: ERROR_NO_LOGIN 
///////////////////////////////////////////////////////////////////////////// 


#include "cs136.h"

///////////////////////////////////////////////////////////////////////////// 
// Do not modify this function

// You MUST use this function to read in an int from input
// (it uses a method from section 05 -- you don't have to understand it yet)

// read_int_or_exit() reads in an integer from input, or exits (terminates)
//   the program if an int cannot be successfully read in
// note: terminates the program quietly with no output displayed
// effects: reads input
//          may terminate program (a rare side effect we don't normally
//                                 worry about in this course)
int read_int_or_exit(void) {
  int n = 0;
  if (scanf("%d", &n) != 1) {
    exit(EXIT_SUCCESS);
  }
  return n;
}
///////////////////////////////////////////////////////////////////////////// 


int main(void) {

}
