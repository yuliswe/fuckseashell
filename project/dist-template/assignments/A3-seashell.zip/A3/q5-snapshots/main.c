// This is a program to test your snapshot (memory tracing) skills

// notes: the style guide is not 100% followed
//        the functions intentionally lack appropriate documentation

#include "cs136.h"

// SEASHELL_READONLY

int at_count = 2;
int snapshot_count = 1;
int star_count = 0;

void take_snapshot(void) {
  printf("\nsnapshot #%d\n", snapshot_count);
  // TAKE A MEMORY SNAPSHOT NOW
  snapshot_count++;
}

void print_at(void) {
  printf("@");
  at_count += 1;
}

void print_stars(int n) {
  if (n > 0) {
    printf("*");
    ++star_count;
    if (star_count == at_count) {
      take_snapshot();
    }
    print_stars(n - 1);
  }
}

int print_stuff(int j, int k) {
  const int m = k - j;
  int i = 0;
  for (i = j; i <= k; i += 2) {
    print_at();
    print_stars(i);
    if (i > j) {
      take_snapshot();
    }
  }
  return i + m;
}

int main(void) {
  const int c = 13;
  const int d = print_stuff(0, 5);
  take_snapshot();
  assert(c * d);                       // just to ignore warnings
}

const int course_id = 136;
